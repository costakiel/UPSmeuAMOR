
const slides = document.querySelectorAll('.carrossel-slide');
let slideAtual = 0;
const mostrarSlide = (index) => {
  slides.forEach(slide => slide.classList.remove('active'));
  slides[index].classList.add('active');
};
setInterval(() => {
  if (slides[slideAtual].tagName === 'VIDEO' && !slides[slideAtual].ended) return;
  slideAtual = (slideAtual + 1) % slides.length;
  mostrarSlide(slideAtual);
}, 5000);

const inicio = new Date('2023-07-22T21:00:00');
const contador = document.getElementById('contador');
setInterval(() => {
  const agora = new Date();
  const diff = agora - inicio;
  const dias = Math.floor(diff / (1000 * 60 * 60 * 24));
  const horas = Math.floor((diff / (1000 * 60 * 60)) % 24);
  const minutos = Math.floor((diff / (1000 * 60)) % 60);
  const segundos = Math.floor((diff / 1000) % 60);
  contador.textContent = `${dias}d ${horas}h ${minutos}m ${segundos}s`;
}, 1000);
